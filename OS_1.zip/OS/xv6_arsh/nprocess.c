#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{ 
  if(argc != 2){ 
    printf(2,"Error number of arguments specified != 2!\n ");
    exit();
  }
  int i=0;
  int n=atoi(argv[1]);
  n-=2;
  int pid=fork();

  for(i=1;i<n;i++){
     if(!pid){
        pid=fork();
     }
  }
  if(!pid){
    wait();
    goto EXIT;
  }
  sleep(1000);
  EXIT:
  exit();
}
