#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{ 
  if(argc < 2){ 
    printf(2," smaller number of arguments than specified , error !\n ");
    exit();
  }

  if(argc > 2){
    printf(2," greater number of arguments than specified , error !\n ");
    exit();
  }

  int i=0;
  int num=atoi(argv[1]);

  num--;

  int pp=fork();

  for(i=1;i<num;i++){
     if(pp == 0 ){
        pp=fork();
     }
  }

  if(pp != 0){
     wait();
     exit();
  }

  sleep(1000);
  exit();
}
